# Auto Generate Collision — Mobile Friendly Godot 4 Plugin

**One-click collision generation for 3D scenes — designed for mobile Godot devs.**

---

## Features

- One-click collision for all meshes
- High precision Trimesh (≈100%)
- Supports GLB/GLTF instanced models
- Safe to run multiple times

---

## Installation

1. Copy `addons/auto_collision_free/` to your project
2. Enable in Project Settings → Plugins
3. "Auto Collision" tab appears in bottom panel

---

## How to Use

1. Open your 3D scene
2. Enable Editable Children (for instanced models)
3. Click Generate Collision

---

## Free vs PRO

**Free:**
- Trimesh Collision ✅
- Free

**PRO ($3.50):**
- Trimesh Collision ✅
- Convex Collision ✅
- Multi Convex ✅
- Auto Editable Children ✅
- Filter & Auto Replace ✅

🔗 **[Buy PRO on Itch.io] (https://raykit-studio.itch.io/smart-collision-pro)**

---

**License:** MIT — Free for commercial use